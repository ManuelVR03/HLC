var cadena = prompt("Introduce una cadena: ");
console.log(cadena.trim());
console.log(cadena.replaceAll("a", "u"));
console.log(cadena.split(" "));
