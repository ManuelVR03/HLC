window.onload = function (){
    document.getElementById("ciudad").textContent = prompt("Introduce una ciudad: ");
    document.getElementById("gastos").textContent = prompt("Introduce los gastos de envio: ") + "€";
    document.getElementById("fecha").textContent = prompt("Introduce la fecha de hoy: ");

}