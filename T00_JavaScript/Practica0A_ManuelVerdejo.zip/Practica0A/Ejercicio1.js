var nombre = prompt("¿Cómo te llamas? ");
document.write("<h1>Hola " + nombre + "</h1>");
document.write("<h4>Tu nombre tiene " + nombre.length + " letras.</h4>");
